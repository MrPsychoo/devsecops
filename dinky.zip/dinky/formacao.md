---
layout: default
---

# Formação Acadêmica

* * *
![formacao](/assets/images/formacao.jpg)
* * *
## Graduação

**Nível de Formação**: Graduação em Sistemas para Internet\
**Local de Ensino**: Faculdade de Negócios e Tecnologias da Informação\
**Conclusão**: 2º semestre de 2010

* * *
## Pós-graduação

**Nível de Formação**: Pós-graduação em Desenvolvimento de Sistemas para Web\
**Local de Ensino**: Faculdade BSB\
**Conclusão**: 1º semestre de 2013

* * *
## Cursos

- ### Recursos Humanos
  - **Instituição**: Centro Miguel Magone
  - **Especialidade**: Auxiliar de Escritório, Telefonista e Relações Humanas
  - **Período**: 3 Meses 
  
- ### Eletrotécnico
  - **Instituição**: Escola Técnica
  - **Especialidade**: Auxiliar de Eletrotécnico de Baixa Tensão
  - **Período**: 12 Meses

- ### Departamento de Pessoal
  - **Instituição**: Serviço Nacional de Aprendizagem Comercial
  - **Especialidade**: Auxiliar de Departamento de Pessoal
  - **Período**: 184 horas

[Voltar](./)
