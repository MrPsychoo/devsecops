---
layout: default
---

# Conhecimentos em Informática

* * *
![informatica](/assets/images/informatica.jpg)
* * *
## Informática
- ### Exata
  - **Especialidade**: IPD, Windows 95/98/2000 Professional, Word, Excel, PowerPoint, Corel Draw, Page Maker, Access, Html, Front Page, Digitação e Internet - (Período: 1 ano)

- ### Escola Técnica
  - **Especialidade**: Operador de Micro - (Período: 1 ano)

- ### Hytec
  - **Especialidade**: Excel básico - (Período: 15 horas)

- ### Escola Técnica
  - **Especialidade**: Lógica de programação - (Período: 40 horas)

- ### Escola Técnica
  - **Especialidade**: WEB Design Módulo 1 HTML/DreamWaver – (Período: 40 horas)

- ### Escola Técnica
  - **Especialidade**: JavaScript/VBScript - (Período: 40 horas)

- ### IV Fórum da Informação
  - **Especialidade**: PHP e MySQL - (Período: 40 horas) 

- ### Instituto Científico
  - **Especialidade**: Java - (Período: 40 horas) 

- ### Instituto de Desenvolvimento Empresarial
  - **Especialidade**: Excel avançado - (Período: 32 horas)

[Voltar](./)
