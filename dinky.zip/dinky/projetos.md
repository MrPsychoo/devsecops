---
layout: default
---

# Projetos e Conquistas

* * *
![projetos](/assets/images/projetos.jpg)
* * *
## Loterias
- **Descrição**: Site destinado a controle, acompanhamento e registros de apostas de loterias on-line
	- **Site**: [www.lotusdourado.com](https://www.lotusdourado.com)

## Cryptomoedas
- **Descrição**: Site para divulgação e acompanhamento de moedas digitais - Cryptomoedas
	- **Site**: [www.maxtobit.com](https://www.maxtobit.com)

## Floricultura
- **Descrição**: Site para vendas de flores on-line, e-commerce de produtos naturais
	- **Site**: [www.flordocampoftg.com](https://www.flordocampoftg.com)

## Agenda Saúde
- **Descrição**: Site para agendamentos de consultas médicas e acompanhamento das agendas registradas
	- **Site**: [www.saudeemcasa009.com](https://www.saudeemcasa009.com)

[Voltar](./)
