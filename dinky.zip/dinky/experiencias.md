---
layout: default
---

# Experiências Profissionais

* * *
![experiencias](/assets/images/experiencias.jpg)
* * *
## Experiências
 
- ### Tecnologia e Produtos
  - **Área**: Departamento de Pessoal
  - **Função**: Auxiliar de Apoio e Administrativo
  - **Período**: Agosto/2002 – Julho/2004 (1 ano e 11 meses)
  - **Atividades**: Atendimento ao publico, Atendimento de telefones e Arquivista.

- ### Turismo S.A.
  - **Área**: Desenvolvedor PHP
  - **Função**: Temporário
  - **Período**: Janeiro/2011 até Junho/2011
  - **Atividades**: Desenvolvimento e manutenção de páginas WEB utilizando a linguagem PHP, gerenciamento de e-mails dos profissionais e do e-mail marketing da empresa, adequação do design do portal e manutenção diária.

- ### Tecnologia e Produtos	
  - **Área**: Departamento de Pessoal
  - **Função**:	Assistente de Pessoal
  - **Período**:	Agosto/2004 até Agosto/2011
  - **Atividades**:	Gestão sobre estagiários, crachás, arquivo, seguro de vida, assistência de documentos para defesa processual, rescisões, referências profissionais, Matriz e Filiais.

- ### Centro de Desenvolvimento Tecnológico
  - **Área**: Núcleo de Pesquisa
  - **Função**: Bolsa de Pesquisa
  - **Período**: Dezembro/2011 até Agosto/2013
  - **Atividades**: Desenvolvimento de aplicações para apoio ao desenvolvimento tecnológico e aplicações internas, manutenção em sistemas internos e externos, utilizando Zend Framework, jQuery, Ajax, MySql, PostgreSQL, outras linguagens e ferramentas de auxílio ao PHP, manutenção e implementações no sistema desenvolvido no dotProject.

- ### Gestão de Piscinas
  - **Área**: Tecnologia da Informação
  - **Função**: Desenvolvimento de Aplicações sem Vínculo Empregatício
  - **Período**: Dezembro/2013 até Dezembro/2016
  - **Atividades**: Desenvolvimento de aplicações para controle de clientes, fornecedores, estoque, emissão de orçamentos, renovação de contratos e demais gerenciamentos, utilizando Zend Framework, jQuery, Ajax, MySql, PostgreSQL, outras linguagens e ferramentas de auxílio ao PHP.

- ### B Federal
  - **Área**: TI
  - **Função**: Assistente
  - **Período**: Atual
  - **Atividades**: Desenvolvimento/manutenção de aplicações em Angular, Java, com base de dados Oracle, DB2, auxílio na resolução de pendências e necessidades para fábricas de software, comunicação com áreas para discussão e resolução de necessidades, auxílio nas demandas RTC, acompanhamento e disponibilização para homologação de gestores, criação e solicitação de requisições de mudança para o ambiente produtivo.

[Voltar](./)
